# ☕ Caffeine.OD — by Siddharth Mohanty

A premium coffee pop-up ordering system. Guests scan a QR code, enter their name & phone, browse the menu, place an order, and pay via UPI.

---

## 🗂 Project Structure

```
caffeine-od/
├── app/
│   ├── layout.js          # Root layout, fonts, Toaster
│   ├── page.js            # Landing / User entry screen
│   ├── menu/
│   │   └── page.js        # Menu with item cards & cart
│   ├── order/
│   │   └── page.js        # Order summary / Invoice
│   └── payment/
│       └── page.js        # Payment screen with QR
├── components/
│   ├── MenuCard.jsx       # Individual coffee card with qty selector
│   └── PreviousOrders.jsx # Collapsible past order history
├── lib/
│   ├── firebase.js        # Firebase init + Firestore helpers
│   ├── AppContext.js      # Global state (user, cart, order)
│   └── menuData.js        # Menu items data
├── styles/
│   └── globals.css        # Global styles + Google Fonts
├── .env.local.example     # Firebase env vars template
├── firebase.json          # Firebase Hosting config
├── firestore.rules        # Firestore security rules
├── next.config.js         # Next.js static export config
├── tailwind.config.js     # Tailwind custom theme
└── package.json
```

---

## 🚀 Running Locally

### 1. Clone & Install

```bash
git clone <your-repo>
cd caffeine-od
npm install
```

### 2. Set Up Firebase

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project (e.g. `caffeine-od`)
3. Enable **Firestore Database** (start in test mode)
4. Add a **Web App** in Project Settings → Your Apps
5. Copy the config values

### 3. Configure Environment Variables

```bash
cp .env.local.example .env.local
```

Edit `.env.local` and fill in your Firebase values:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSy...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=caffeine-od.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=caffeine-od
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=caffeine-od.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abc123
```

### 4. Run the Dev Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) on your phone or browser.

---

## 🔥 Deploy to Firebase Hosting

### 1. Install Firebase CLI

```bash
npm install -g firebase-tools
firebase login
```

### 2. Initialize Firebase in the project

```bash
firebase init
```

Select:
- ✅ Hosting
- ✅ Firestore (to deploy rules)

When asked for public directory, type: `out`

### 3. Build & Deploy

```bash
npm run build        # builds Next.js static export to /out
firebase deploy      # deploys to Firebase Hosting
```

Your app will be live at: `https://your-project-id.web.app`

### 4. Deploy Firestore Rules

```bash
firebase deploy --only firestore:rules
```

---

## 📱 QR Code for Guests

After deploying, generate a QR code pointing to your Firebase Hosting URL using any free QR generator:
- [QR Code Generator](https://www.qr-code-generator.com/)
- [goqr.me](https://goqr.me/)

Print it or display it on a screen at the pop-up.

---

## 💳 Setting Up Real UPI Payment QR

In `app/payment/page.js`, replace the `<QRPlaceholder />` component with an actual `<img>` tag:

```jsx
// Replace the QRPlaceholder with:
<img
  src="/images/upi-qr.png"
  alt="UPI Payment QR"
  className="w-52 h-52 object-cover rounded-xl"
/>
```

Then save your UPI QR image as `public/images/upi-qr.png`.

You can generate a UPI QR from:
- PhonePe / GPay / Paytm → "Receive Money" → Save QR
- [UPI QR Generator](https://www.upilink.in/)

---

## 🗃 Firestore Data Structure

```
users/
  └── {phoneNumber}/
        ├── name: "Arjun"
        ├── phoneNumber: "9876543210"
        ├── createdAt: Timestamp
        ├── updatedAt: Timestamp
        └── orders: [
              {
                orderId: "ORD-1718123456789",
                items: [
                  { name: "Monkey Business", qty: 1, price: 350 },
                  { name: "Cold Kaapi", qty: 2, price: 250 }
                ],
                total: 850,
                timestamp: "2024-06-12T10:30:00.000Z",
                status: "placed"
              }
            ]
```

---

## 🎨 Design System

| Token | Value | Usage |
|-------|-------|-------|
| `cream` | `#F5EFE0` | Page background |
| `parchment` | `#EDE3CC` | Card borders, dividers |
| `espresso` | `#2C1810` | Primary text, buttons |
| `amber` | `#C17D3C` | Accents, highlights |
| `gold` | `#D4A853` | Secondary accents |
| `ash` | `#6B5E52` | Muted/secondary text |

**Fonts:** Playfair Display (headings) + DM Sans (body)

---

## ✏️ Customization

### Add / Edit Menu Items

Edit `lib/menuData.js`:

```js
{
  id: 'your-drink-id',
  name: 'Drink Name',
  price: 300,
  description: 'Your description here.',
  tag: 'New',
  emoji: '🧋',
  accentColor: '#C17D3C',
}
```

### Change Pop-up Name / Branding

Search for `Caffeine.OD` and `Siddharth Mohanty` across the codebase and replace with your details.

---

## 📋 Tech Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 14 (App Router) |
| Styling | Tailwind CSS |
| Animations | CSS keyframes |
| Database | Firebase Firestore |
| Hosting | Firebase Hosting |
| Toasts | react-hot-toast |

---

## ⚠️ Security Note

The current Firestore rules allow open read/write (suitable for a trusted private pop-up). For a public-facing deployment, integrate Firebase Authentication.

---

*Built with ☕ and love for the craft.*
