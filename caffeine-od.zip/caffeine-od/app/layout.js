import '../styles/globals.css';
import { Toaster } from 'react-hot-toast';
import { AppProvider } from '../lib/AppContext';

export const metadata = {
  title: 'Caffeine.OD — by Siddharth Mohanty',
  description: 'A premium coffee pop-up experience. Order your brew.',
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-cream">
        <AppProvider>
          {children}
          <Toaster
            position="top-center"
            toastOptions={{
              style: {
                background: '#2C1810',
                color: '#F5EFE0',
                fontFamily: "'DM Sans', sans-serif",
                fontSize: '14px',
                borderRadius: '12px',
                padding: '12px 18px',
                border: '1px solid rgba(193, 125, 60, 0.3)',
              },
              success: {
                iconTheme: {
                  primary: '#C17D3C',
                  secondary: '#F5EFE0',
                },
              },
            }}
          />
        </AppProvider>
      </body>
    </html>
  );
}
