'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useApp } from '../../lib/AppContext';
import { MENU_ITEMS } from '../../lib/menuData';
import MenuCard from '../../components/MenuCard';
import PreviousOrders from '../../components/PreviousOrders';

export default function MenuPage() {
  const router = useRouter();
  const { user, cart, updateCart, totalItems } = useApp();

  // Guard: redirect to home if no user
  useEffect(() => {
    if (!user) router.replace('/');
  }, [user, router]);

  if (!user) return null;

  const totalAmount = MENU_ITEMS.reduce((sum, item) => {
    return sum + (cart[item.name] || 0) * item.price;
  }, 0);

  const isReturning = user.orders && user.orders.length > 0;

  return (
    <main className="min-h-screen bg-cream pb-32">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-cream/90 backdrop-blur-md border-b border-parchment">
        <div className="px-5 py-4 flex items-center justify-between">
          <div>
            <p className="font-body text-xs text-ash uppercase tracking-widest">ordering as</p>
            <p className="font-display text-lg font-semibold text-espresso leading-tight">
              {user.name}
            </p>
          </div>
          <div className="text-right">
            <p className="font-body text-xs text-ash uppercase tracking-widest">pop-up</p>
            <p className="font-display text-lg font-bold text-amber leading-tight">
              Caffeine<span className="text-espresso">.</span>OD
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 pt-6">
        {/* Welcome back section for returning users */}
        {isReturning && (
          <div className="mb-6 bg-amber/10 border border-amber/25 rounded-2xl p-4 flex items-center gap-3">
            <span className="text-2xl">👋</span>
            <div>
              <p className="font-body font-medium text-espresso text-sm">Welcome back!</p>
              <p className="font-body text-ash text-xs">
                You've ordered {user.orders.length} time{user.orders.length > 1 ? 's' : ''} before.
              </p>
            </div>
          </div>
        )}

        {/* Previous orders */}
        {isReturning && <PreviousOrders orders={user.orders} />}

        {/* Current menu */}
        <div className="mb-5">
          <div className="flex items-center gap-3 mb-5">
            <div className="h-px flex-1 bg-parchment" />
            <p className="font-body text-xs text-ash uppercase tracking-[0.2em] whitespace-nowrap">
              {isReturning ? 'New Order' : 'The Menu'}
            </p>
            <div className="h-px flex-1 bg-parchment" />
          </div>

          <p className="font-display text-3xl font-bold text-espresso mb-1">
            What are you{' '}
            <span className="italic font-normal text-amber">brewing</span>?
          </p>
          <p className="font-body text-ash text-sm mb-6">
            Handcrafted with love. Each cup made fresh.
          </p>

          <div className="grid grid-cols-1 gap-5">
            {MENU_ITEMS.map((item, idx) => (
              <div
                key={item.id}
                className="opacity-0 animate-fade-up"
                style={{ animationDelay: `${idx * 0.08}s`, animationFillMode: 'forwards' }}
              >
                <MenuCard
                  item={item}
                  qty={cart[item.name] || 0}
                  onAdd={() => updateCart(item.name, 1)}
                  onRemove={() => updateCart(item.name, -1)}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Floating cart bar */}
      {totalItems > 0 && (
        <div className="fixed bottom-6 left-5 right-5 z-30 animate-fade-up">
          <button
            onClick={() => router.push('/order')}
            className="w-full bg-espresso text-cream rounded-2xl py-4 px-6 flex items-center justify-between shadow-2xl shadow-espresso/30 transition-all active:scale-[0.98]"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber/20 flex items-center justify-center">
                <span className="font-body font-bold text-amber text-sm">{totalItems}</span>
              </div>
              <span className="font-body font-medium text-sm">
                {totalItems} item{totalItems !== 1 ? 's' : ''} selected
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-body font-semibold text-amber">₹{totalAmount}</span>
              <span className="font-body text-sm text-cream/70">→</span>
            </div>
          </button>
        </div>
      )}
    </main>
  );
}
