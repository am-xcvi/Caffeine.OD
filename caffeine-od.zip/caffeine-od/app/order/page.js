'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { useApp } from '../../lib/AppContext';
import { MENU_ITEMS } from '../../lib/menuData';
import { placeOrder } from '../../lib/firebase';

export default function OrderPage() {
  const router = useRouter();
  const { user, cart, clearCart, setCurrentOrder } = useApp();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) router.replace('/');
  }, [user, router]);

  if (!user) return null;

  // Build order items from cart
  const orderItems = MENU_ITEMS
    .filter(item => (cart[item.name] || 0) > 0)
    .map(item => ({
      name: item.name,
      qty: cart[item.name],
      price: item.price,
    }));

  const total = orderItems.reduce((sum, item) => sum + item.qty * item.price, 0);

  if (orderItems.length === 0) {
    return (
      <main className="min-h-screen bg-cream flex flex-col items-center justify-center px-6 gap-4">
        <span className="text-5xl">🛒</span>
        <p className="font-display text-xl text-espresso">Your cart is empty</p>
        <p className="font-body text-ash text-sm text-center">Head back to the menu to pick your brews.</p>
        <button
          onClick={() => router.push('/menu')}
          className="mt-2 bg-espresso text-cream font-body text-sm px-6 py-3 rounded-2xl"
        >
          ← Back to Menu
        </button>
      </main>
    );
  }

  async function handlePlaceOrder() {
    setLoading(true);
    try {
      const order = await placeOrder(user.phoneNumber, orderItems, total);
      setCurrentOrder(order);
      clearCart();

      toast.success('Order placed! ☕', {
        duration: 2500,
      });

      setTimeout(() => router.push('/payment'), 500);
    } catch (err) {
      console.error(err);
      toast.error('Failed to place order. Try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-cream">
      {/* Header */}
      <div className="px-5 pt-8 pb-4">
        <button
          onClick={() => router.back()}
          className="flex items-center gap-1.5 text-ash font-body text-sm mb-6 transition-colors active:text-espresso"
        >
          ← Edit order
        </button>

        <p className="font-body text-xs text-ash uppercase tracking-widest mb-1">Review</p>
        <h1 className="font-display text-3xl font-bold text-espresso">
          Your <span className="italic font-normal text-amber">Order</span>
        </h1>
      </div>

      {/* Order card */}
      <div className="px-5 pb-36">
        <div className="bg-white/70 border border-parchment rounded-3xl overflow-hidden shadow-sm">
          {/* Customer info */}
          <div className="px-6 py-4 bg-espresso/5 border-b border-parchment flex items-center justify-between">
            <div>
              <p className="font-body text-xs text-ash uppercase tracking-wide">Order for</p>
              <p className="font-display text-lg font-semibold text-espresso">{user.name}</p>
            </div>
            <div className="text-right">
              <p className="font-body text-xs text-ash uppercase tracking-wide">Phone</p>
              <p className="font-body text-sm text-espresso">+91 {user.phoneNumber}</p>
            </div>
          </div>

          {/* Items */}
          <div className="px-6 py-2">
            {orderItems.map((item, i) => (
              <div
                key={item.name}
                className="flex items-center justify-between py-4 opacity-0 animate-fade-up"
                style={{ animationDelay: `${i * 0.06}s`, animationFillMode: 'forwards', borderBottom: i < orderItems.length - 1 ? '1px solid #EDE3CC' : 'none' }}
              >
                <div className="flex items-center gap-3 flex-1">
                  <div className="w-8 h-8 rounded-xl bg-amber/15 flex items-center justify-center shrink-0">
                    <span className="font-body font-bold text-amber text-xs">×{item.qty}</span>
                  </div>
                  <div>
                    <p className="font-body font-medium text-espresso text-sm leading-snug">{item.name}</p>
                    <p className="font-body text-ash text-xs">₹{item.price} each</p>
                  </div>
                </div>
                <p className="font-body font-semibold text-espresso text-sm tabular-nums">
                  ₹{item.qty * item.price}
                </p>
              </div>
            ))}
          </div>

          {/* Subtotal breakdown */}
          <div className="px-6 py-4 bg-parchment/40 border-t border-parchment">
            {orderItems.length > 1 && (
              <div className="flex justify-between mb-2">
                <span className="font-body text-ash text-xs uppercase tracking-wide">
                  {orderItems.reduce((a, b) => a + b.qty, 0)} items
                </span>
                <span className="font-body text-ash text-xs">₹{total}</span>
              </div>
            )}
            <div className="flex justify-between items-baseline">
              <span className="font-display text-xl font-semibold text-espresso">Total</span>
              <span className="font-display text-2xl font-bold text-amber">₹{total}</span>
            </div>
          </div>
        </div>

        {/* Note */}
        <div className="mt-4 flex items-start gap-2 px-1">
          <span className="text-amber text-sm mt-0.5">✦</span>
          <p className="font-body text-ash text-xs leading-relaxed">
            Payment will be collected after placing your order via UPI QR code.
          </p>
        </div>
      </div>

      {/* Fixed bottom action */}
      <div className="fixed bottom-0 left-0 right-0 px-5 pb-8 pt-4 bg-gradient-to-t from-cream via-cream/95 to-transparent">
        <button
          onClick={handlePlaceOrder}
          disabled={loading || orderItems.length === 0}
          className="w-full bg-espresso text-cream rounded-2xl py-4 font-body font-medium text-base tracking-wide transition-all active:scale-[0.98] disabled:opacity-60 relative overflow-hidden"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="w-4 h-4 border-2 border-cream/30 border-t-cream rounded-full animate-spin" />
              Placing order...
            </span>
          ) : (
            <span className="flex items-center justify-center gap-2">
              ☕ Place Order · ₹{total}
            </span>
          )}
        </button>
      </div>
    </main>
  );
}
