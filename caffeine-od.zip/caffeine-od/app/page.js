'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { upsertUser } from '../lib/firebase';
import { useApp } from '../lib/AppContext';

export default function LandingPage() {
  const router = useRouter();
  const { setUser } = useApp();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  function validate() {
    const errs = {};
    if (!name.trim()) errs.name = 'What shall we call you?';
    if (!/^[6-9]\d{9}$/.test(phone.trim())) errs.phone = 'Enter a valid 10-digit number';
    return errs;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }

    setLoading(true);
    try {
      const userData = await upsertUser(phone.trim(), name.trim());
      setUser(userData);

      if (userData.orders && userData.orders.length > 0) {
        toast(`Welcome back, ${userData.name}! ☕`, { icon: '👋' });
      } else {
        toast(`Hey ${userData.name}! Let's get brewing 🫶`);
      }

      router.push('/menu');
    } catch (err) {
      console.error(err);
      toast.error('Something went wrong. Try again?');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-cream flex flex-col items-center justify-between px-6 py-12 relative overflow-hidden">

      {/* Background decorative circles */}
      <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-amber/10 -translate-y-1/2 translate-x-1/2 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-gold/10 translate-y-1/3 -translate-x-1/3 blur-3xl pointer-events-none" />

      {/* Top strip */}
      <div className="w-full text-center opacity-0 animate-fade-up stagger-1">
        <p className="text-ash text-xs tracking-[0.25em] uppercase font-body">
          Home Pop-Up · Est. 2024
        </p>
      </div>

      {/* Logo / Header */}
      <div className="flex flex-col items-center gap-4 opacity-0 animate-fade-up stagger-2">
        {/* Coffee cup icon */}
        <div className="relative w-20 h-20 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-amber/30" />
          <div className="absolute inset-2 rounded-full border border-amber/20" />
          <span className="text-4xl">☕</span>
        </div>

        <div className="text-center">
          <h1 className="font-display text-5xl font-bold text-espresso leading-none tracking-tight">
            Caffeine
            <span className="text-amber">.</span>OD
          </h1>
          <p className="font-display italic text-ash text-sm mt-1 tracking-wide">
            by Siddharth Mohanty
          </p>
        </div>

        <div className="flex items-center gap-3 mt-2">
          <div className="h-px w-12 bg-amber/40" />
          <p className="text-ash font-body text-xs tracking-[0.2em] uppercase">
            Order Your Brew
          </p>
          <div className="h-px w-12 bg-amber/40" />
        </div>
      </div>

      {/* Form Card */}
      <div className="w-full max-w-sm opacity-0 animate-fade-up stagger-3">
        <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-7 shadow-sm border border-parchment">
          <p className="font-display text-xl text-espresso font-medium mb-1">
            Let's get started
          </p>
          <p className="font-body text-ash text-sm mb-6">
            We'll remember your order for next time.
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            {/* Name */}
            <div>
              <label className="block font-body text-xs text-ash uppercase tracking-widest mb-2">
                Your Name
              </label>
              <input
                type="text"
                placeholder="Arjun, Priya, Ravi..."
                value={name}
                onChange={e => { setName(e.target.value); setErrors(p => ({ ...p, name: '' })); }}
                className={`w-full bg-cream/80 border rounded-2xl px-5 py-4 font-body text-espresso placeholder:text-ash/40 text-base transition-all focus:bg-white/80
                  ${errors.name ? 'border-red-400' : 'border-parchment focus:border-amber'}`}
              />
              {errors.name && (
                <p className="text-red-500 text-xs mt-1.5 font-body pl-1">{errors.name}</p>
              )}
            </div>

            {/* Phone */}
            <div>
              <label className="block font-body text-xs text-ash uppercase tracking-widest mb-2">
                Phone Number
              </label>
              <div className="relative">
                <span className="absolute left-5 top-1/2 -translate-y-1/2 text-ash font-body text-base select-none">
                  +91
                </span>
                <input
                  type="tel"
                  inputMode="numeric"
                  maxLength={10}
                  placeholder="98765 43210"
                  value={phone}
                  onChange={e => { setPhone(e.target.value.replace(/\D/g, '')); setErrors(p => ({ ...p, phone: '' })); }}
                  className={`w-full bg-cream/80 border rounded-2xl px-5 py-4 pl-14 font-body text-espresso placeholder:text-ash/40 text-base transition-all focus:bg-white/80
                    ${errors.phone ? 'border-red-400' : 'border-parchment focus:border-amber'}`}
                />
              </div>
              {errors.phone && (
                <p className="text-red-500 text-xs mt-1.5 font-body pl-1">{errors.phone}</p>
              )}
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="mt-2 w-full bg-espresso text-cream rounded-2xl py-4 font-body font-medium text-base tracking-wide transition-all duration-200 active:scale-[0.98] disabled:opacity-60 relative overflow-hidden group"
            >
              <span className="relative z-10">
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <LoadingDots />
                    Setting you up...
                  </span>
                ) : 'See the Menu →'}
              </span>
              <div className="absolute inset-0 bg-amber opacity-0 group-active:opacity-20 transition-opacity" />
            </button>
          </form>
        </div>

        <p className="text-center text-ash/60 font-body text-xs mt-5">
          Your data stays private & is only used to remember your orders ✦
        </p>
      </div>

      {/* Bottom tagline */}
      <div className="opacity-0 animate-fade-up stagger-4 text-center">
        <p className="font-display italic text-ash/50 text-sm">
          "Good coffee, good vibes."
        </p>
      </div>
    </main>
  );
}

function LoadingDots() {
  return (
    <span className="flex gap-1 items-center">
      {[0, 1, 2].map(i => (
        <span
          key={i}
          className="w-1.5 h-1.5 bg-cream/70 rounded-full animate-bounce"
          style={{ animationDelay: `${i * 0.15}s` }}
        />
      ))}
    </span>
  );
}
