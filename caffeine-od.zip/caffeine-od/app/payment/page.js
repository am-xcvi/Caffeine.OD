'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useApp } from '../../lib/AppContext';

function formatOrderId(id) {
  if (!id) return '—';
  return id.replace('ORD-', '#');
}

export default function PaymentPage() {
  const router = useRouter();
  const { user, currentOrder } = useApp();

  useEffect(() => {
    if (!user) router.replace('/');
    if (!currentOrder) router.replace('/menu');
  }, [user, currentOrder, router]);

  if (!user || !currentOrder) return null;

  return (
    <main className="min-h-screen bg-cream flex flex-col">
      {/* Header */}
      <div className="px-5 pt-8 pb-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
            <span className="text-lg">✓</span>
          </div>
          <div>
            <p className="font-body text-xs text-ash uppercase tracking-widest">Order confirmed</p>
            <p className="font-display font-semibold text-espresso text-base">
              {formatOrderId(currentOrder.orderId)}
            </p>
          </div>
        </div>

        <p className="font-display text-3xl font-bold text-espresso mb-1">
          Now <span className="italic font-normal text-amber">pay up</span> ☕
        </p>
        <p className="font-body text-ash text-sm">
          Scan the QR below to complete your payment.
        </p>
      </div>

      <div className="flex-1 px-5 pb-10 flex flex-col gap-5">
        {/* Amount card */}
        <div className="bg-espresso rounded-3xl p-6 text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-amber -translate-y-1/3 translate-x-1/3" />
            <div className="absolute bottom-0 left-0 w-32 h-32 rounded-full bg-amber translate-y-1/2 -translate-x-1/3" />
          </div>
          <p className="font-body text-cream/60 text-xs uppercase tracking-widest mb-2 relative z-10">
            Amount to pay
          </p>
          <p className="font-display text-5xl font-bold text-cream relative z-10">
            ₹{currentOrder.total}
          </p>
          <p className="font-body text-cream/50 text-xs mt-2 relative z-10">
            {currentOrder.items.length} item{currentOrder.items.length !== 1 ? 's' : ''}
          </p>
        </div>

        {/* QR code placeholder */}
        <div className="bg-white/80 border border-parchment rounded-3xl p-6 flex flex-col items-center gap-4">
          <p className="font-body text-ash text-xs uppercase tracking-[0.2em]">Scan to Pay</p>

          {/* QR Placeholder */}
          <div className="relative">
            <div className="w-52 h-52 bg-cream border-2 border-dashed border-parchment rounded-2xl flex flex-col items-center justify-center gap-3">
              {/* Fake QR pattern */}
              <QRPlaceholder />
            </div>

            {/* Corner decorations */}
            {['tl', 'tr', 'bl', 'br'].map(corner => (
              <div
                key={corner}
                className="absolute w-6 h-6 border-espresso"
                style={{
                  top: corner.startsWith('t') ? -2 : 'auto',
                  bottom: corner.startsWith('b') ? -2 : 'auto',
                  left: corner.endsWith('l') ? -2 : 'auto',
                  right: corner.endsWith('r') ? -2 : 'auto',
                  borderTopWidth: corner.startsWith('t') ? 3 : 0,
                  borderBottomWidth: corner.startsWith('b') ? 3 : 0,
                  borderLeftWidth: corner.endsWith('l') ? 3 : 0,
                  borderRightWidth: corner.endsWith('r') ? 3 : 0,
                  borderRadius: corner === 'tl' ? '4px 0 0 0' : corner === 'tr' ? '0 4px 0 0' : corner === 'bl' ? '0 0 0 4px' : '0 0 4px 0',
                }}
              />
            ))}
          </div>

          <div className="text-center">
            <p className="font-display text-xl font-semibold text-espresso">Scan to pay</p>
            <p className="font-display italic text-amber text-base">Siddharth</p>
          </div>

          <div className="w-full bg-cream/80 rounded-2xl px-4 py-3 flex items-center gap-2">
            <span className="text-lg">💳</span>
            <p className="font-body text-sm text-ash">
              UPI · PhonePe · GPay · Paytm — all work.
            </p>
          </div>
        </div>

        {/* Order summary mini */}
        <div className="bg-white/60 border border-parchment rounded-3xl p-5">
          <p className="font-body text-xs text-ash uppercase tracking-widest mb-3">Order Summary</p>
          {currentOrder.items.map((item, i) => (
            <div key={i} className="flex justify-between items-center py-2 border-b border-parchment/60 last:border-0">
              <span className="font-body text-sm text-espresso">
                {item.name} <span className="text-ash">×{item.qty}</span>
              </span>
              <span className="font-body text-sm font-medium text-espresso">₹{item.qty * item.price}</span>
            </div>
          ))}
          <div className="flex justify-between items-center mt-3">
            <span className="font-body text-xs text-ash uppercase tracking-wide">Total Paid</span>
            <span className="font-display font-bold text-amber text-lg">₹{currentOrder.total}</span>
          </div>
        </div>

        {/* Order again */}
        <button
          onClick={() => router.push('/menu')}
          className="w-full border-2 border-espresso/20 text-espresso rounded-2xl py-4 font-body font-medium text-sm tracking-wide transition-all active:scale-[0.98] active:bg-espresso/5"
        >
          + Order more
        </button>

        <p className="text-center font-body text-ash/50 text-xs pb-2">
          Thank you for coming ✦ Come back soon
        </p>
      </div>
    </main>
  );
}

// Decorative QR placeholder
function QRPlaceholder() {
  return (
    <div className="flex flex-col gap-1 p-2 opacity-30">
      {Array.from({ length: 7 }).map((_, row) => (
        <div key={row} className="flex gap-1">
          {Array.from({ length: 7 }).map((_, col) => {
            // Create a QR-like pattern
            const isCorner = (row < 2 && col < 2) || (row < 2 && col > 4) || (row > 4 && col < 2);
            const isRandom = Math.sin(row * 7 + col * 3 + row * col) > 0.1;
            const filled = isCorner || isRandom;
            return (
              <div
                key={col}
                className="w-5 h-5 rounded-[3px]"
                style={{ background: filled ? '#2C1810' : 'transparent' }}
              />
            );
          })}
        </div>
      ))}
      <p className="text-center text-espresso text-xs mt-1 font-body font-medium tracking-wide">
        PLACEHOLDER
      </p>
      <p className="text-center text-espresso/60 text-[10px] font-body">
        Replace with real UPI QR
      </p>
    </div>
  );
}
