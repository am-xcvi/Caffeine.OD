'use client';

export default function MenuCard({ item, qty, onAdd, onRemove }) {
  const { name, price, description, tag, emoji, accentColor } = item;

  return (
    <div
      className="bg-white/70 backdrop-blur-sm border border-parchment rounded-3xl overflow-hidden transition-all duration-200 active:scale-[0.99]"
      style={{
        boxShadow: qty > 0
          ? `0 0 0 2px ${accentColor}40, 0 4px 20px rgba(44, 24, 16, 0.08)`
          : '0 2px 12px rgba(44, 24, 16, 0.06)',
      }}
    >
      {/* Image area */}
      <div
        className="relative h-44 flex items-center justify-center overflow-hidden"
        style={{ background: `linear-gradient(135deg, ${accentColor}15, ${accentColor}25)` }}
      >
        {/* Decorative rings */}
        <div
          className="absolute w-40 h-40 rounded-full opacity-20"
          style={{ border: `1px solid ${accentColor}`, transform: 'scale(1.1)' }}
        />
        <div
          className="absolute w-28 h-28 rounded-full opacity-10"
          style={{ border: `1px solid ${accentColor}`, transform: 'scale(0.8)' }}
        />

        {/* Coffee placeholder art */}
        <div className="relative flex flex-col items-center gap-1">
          <span className="text-6xl drop-shadow-sm" role="img" aria-label={name}>
            {emoji}
          </span>
          <div
            className="text-xs font-body font-medium px-3 py-1 rounded-full mt-1"
            style={{
              background: `${accentColor}20`,
              color: accentColor,
              border: `1px solid ${accentColor}30`,
            }}
          >
            {tag}
          </div>
        </div>

        {/* Selected indicator */}
        {qty > 0 && (
          <div
            className="absolute top-3 right-3 w-7 h-7 rounded-full flex items-center justify-center text-xs font-body font-semibold text-cream"
            style={{ background: accentColor }}
          >
            {qty}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-display text-lg font-semibold text-espresso leading-snug flex-1">
            {name}
          </h3>
          <p
            className="font-body font-semibold text-base whitespace-nowrap"
            style={{ color: accentColor }}
          >
            ₹{price}
          </p>
        </div>

        <p className="font-body text-ash text-sm leading-relaxed mb-5">
          {description}
        </p>

        {/* Quantity controls */}
        {qty === 0 ? (
          <button
            onClick={onAdd}
            className="w-full py-3 rounded-2xl font-body font-medium text-sm tracking-wide transition-all duration-150 active:scale-[0.97]"
            style={{
              background: `${accentColor}15`,
              color: accentColor,
              border: `1.5px solid ${accentColor}40`,
            }}
          >
            + Add to Order
          </button>
        ) : (
          <div className="flex items-center justify-between bg-cream/80 rounded-2xl p-1">
            <button
              onClick={onRemove}
              className="w-10 h-10 rounded-xl flex items-center justify-center font-body text-xl font-light text-espresso transition-all active:scale-90"
              style={{ background: 'rgba(193,125,60,0.12)' }}
            >
              −
            </button>
            <span className="font-body font-semibold text-espresso text-base tabular-nums">
              {qty}
            </span>
            <button
              onClick={onAdd}
              className="w-10 h-10 rounded-xl flex items-center justify-center font-body text-xl font-light text-cream transition-all active:scale-90"
              style={{ background: accentColor }}
            >
              +
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
