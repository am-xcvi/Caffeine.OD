'use client';

import { useState } from 'react';

function formatDate(isoString) {
  try {
    const d = new Date(isoString);
    return d.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return isoString;
  }
}

export default function PreviousOrders({ orders }) {
  const [expanded, setExpanded] = useState(null);

  if (!orders || orders.length === 0) return null;

  return (
    <div className="mb-8">
      <div className="flex items-center gap-3 mb-4">
        <div className="h-px flex-1 bg-parchment" />
        <p className="font-body text-xs text-ash uppercase tracking-[0.2em] whitespace-nowrap">
          Your Past Orders
        </p>
        <div className="h-px flex-1 bg-parchment" />
      </div>

      <div className="flex flex-col gap-3">
        {[...orders].reverse().map((order, idx) => (
          <div
            key={order.orderId || idx}
            className="bg-white/50 border border-parchment rounded-2xl overflow-hidden"
          >
            <button
              onClick={() => setExpanded(expanded === idx ? null : idx)}
              className="w-full flex items-center justify-between p-4 text-left transition-colors active:bg-cream/50"
            >
              <div>
                <p className="font-body text-xs text-ash mb-0.5">
                  {formatDate(order.timestamp)}
                </p>
                <p className="font-body font-medium text-espresso text-sm">
                  {order.items.length} item{order.items.length !== 1 ? 's' : ''} · ₹{order.total}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-body text-amber bg-amber/10 px-2 py-1 rounded-full border border-amber/20">
                  Paid
                </span>
                <span className="text-ash text-sm transition-transform duration-200" style={{ transform: expanded === idx ? 'rotate(180deg)' : 'rotate(0deg)' }}>
                  ↓
                </span>
              </div>
            </button>

            {expanded === idx && (
              <div className="border-t border-parchment px-4 pb-4 pt-3 bg-cream/30">
                {order.items.map((item, i) => (
                  <div key={i} className="flex items-center justify-between py-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-ash font-body text-xs">×{item.qty}</span>
                      <span className="font-body text-sm text-espresso">{item.name}</span>
                    </div>
                    <span className="font-body text-sm text-ash">₹{item.price * item.qty}</span>
                  </div>
                ))}
                <div className="border-t border-parchment mt-2 pt-2 flex justify-between">
                  <span className="font-body text-xs text-ash uppercase tracking-wide">Total</span>
                  <span className="font-body font-semibold text-espresso text-sm">₹{order.total}</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
